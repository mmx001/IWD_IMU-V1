#include"i2c_com.h"

namespace S_pressure
{
// Methods
extern bool Initialize();
extern void Getpressure(double &p);
}
