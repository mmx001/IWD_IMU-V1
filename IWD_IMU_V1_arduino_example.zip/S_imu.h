#include"i2c_com.h"

namespace S_imu
{
// Methods
extern void Initialize();
extern void GetRPY(double &x, double &y, double &z);
extern void GetmRPY(double &x, double &y, double &z);
extern void GetaRPY(double &x, double &y, double &z);
}
