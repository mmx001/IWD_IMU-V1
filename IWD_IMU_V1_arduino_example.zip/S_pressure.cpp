#include "S_pressure.h"

namespace S_pressure
{
uint16_t C[8];
uint8_t model = 0;
float density = 997;
uint32_t D1, D2;
uint8_t buf[3];
int32_t P;
int32_t TEMP;

uint8_t crc4(uint16_t n_prom[])
{
  uint16_t n_rem = 0;

  n_prom[0] = ((n_prom[0]) & 0x0FFF);
  n_prom[7] = 0;

  for ( uint8_t i = 0 ; i < 16; i++ ) {
    if ( i % 2 == 1 ) {
      n_rem ^= (uint16_t)((n_prom[i >> 1]) & 0x00FF);
    } else {
      n_rem ^= (uint16_t)(n_prom[i >> 1] >> 8);
    }
    for ( uint8_t n_bit = 8 ; n_bit > 0 ; n_bit-- ) {
      if ( n_rem & 0x8000 ) {
        n_rem = (n_rem << 1) ^ 0x3000;
      } else {
        n_rem = (n_rem << 1);
      }
    }
  }

  n_rem = ((n_rem >> 12) & 0x000F);

  return n_rem ^ 0x00;
}

bool Initialize()
{
  i2c_com::write(0x76, 0x1E);
  delay(10);
  for ( uint8_t i = 0 ; i < 7 ; i++ )
  {
    i2c_com::readbuf(0x76, 0xA0 + (i * 2), buf, 2);
    C[i] = (buf[0] << 8) | buf[1];
  }
  uint8_t crcRead = C[0] >> 12;
  uint8_t crcCalculated = crc4(C);

  if ( crcCalculated == crcRead )
  {
    return true; // Initialization success
  }

  return false; // CRC fail
}

void Getpressure(double &p)
{
  i2c_com::write(0x76, 0x4A);
  delay(20);
  i2c_com::readbuf(0x76, 0x00, buf, 3);
  D1 = 0;
  D1 = buf[0];
  D1 = (D1 << 8) | buf[1];
  D1 = (D1 << 8) | buf[2];

  i2c_com::write(0x76, 0x5A);
  delay(20);
  i2c_com::readbuf(0x76, 0x00, buf, 3);
  D2 = 0;
  D2 = buf[0];
  D2 = (D2 << 8) | buf[1];
  D2 = (D2 << 8) | buf[2];

  int32_t dT = 0;
  int64_t SENS = 0;
  int64_t OFF = 0;
  int32_t SENSi = 0;
  int32_t OFFi = 0;
  int32_t Ti = 0;
  int64_t OFF2 = 0;
  int64_t SENS2 = 0;

  // Terms called
  dT = D2 - uint32_t(C[5]) * 256l;
  SENS = int64_t(C[1]) * 32768l + (int64_t(C[3]) * dT) / 256l;
  OFF = int64_t(C[2]) * 65536l + (int64_t(C[4]) * dT) / 128l;
  P = (D1 * SENS / (2097152l) - OFF) / (8192l);

  // Temp conversion
  TEMP = 2000l + int64_t(dT) * C[6] / 8388608LL;

  //Second order compensation
  if ((TEMP / 100) < 20)
  { //Low temp
    Ti = (3 * int64_t(dT) * int64_t(dT)) / (8589934592LL);
    OFFi = (3 * (TEMP - 2000) * (TEMP - 2000)) / 2;
    SENSi = (5 * (TEMP - 2000) * (TEMP - 2000)) / 8;
    if ((TEMP / 100) < -15)
    { //Very low temp
      OFFi = OFFi + 7 * (TEMP + 1500l) * (TEMP + 1500l);
      SENSi = SENSi + 4 * (TEMP + 1500l) * (TEMP + 1500l);
    }
  }
  else if ((TEMP / 100) >= 20)
  { //High temp
    Ti = 2 * (dT * dT) / (137438953472LL);
    OFFi = (1 * (TEMP - 2000) * (TEMP - 2000)) / 16;
    SENSi = 0;
  }


  OFF2 = OFF - OFFi;         //Calculate pressure and temp second order
  SENS2 = SENS - SENSi;

  TEMP = (TEMP - Ti);
  P = (((D1 * SENS2) / 2097152l - OFF2) / 8192l) / 10;

  p = ((100.*P) - 101300) / (density * 9.80665);

}
}

