#include "S_imu.h"

namespace S_imu
{
//int16_t x, y, z;

void Initialize()
{
  i2c_com::write8(0x28, 0x3F, 0x20);
  uint8_t id;
  do
  {
    id = i2c_com::read8(0x28, 0x00);
    delay(500);
  }
  while(id != 0xA0);
  i2c_com::write8(0x28, 0x3E, 0x00);
  delay(50);
  do
  {
    id = i2c_com::read8(0x28, 0x00);
    delay(500);
  }
  while(id != 0xA0);
  i2c_com::write8(0x28, 0x3D, 0x0C);
  delay(50);
}

void GetRPY(double &x, double &y, double &z)
{
  uint8_t buf[6];
  i2c_com::readbuf(0x28, 0x1A, buf, 6);

  x = ((double)(((int16_t)buf[0]) | (((int16_t)buf[1]) << 8))) / 16.0;
  y = ((double)(((int16_t)buf[2]) | (((int16_t)buf[3]) << 8))) / 16.0;
  z = ((double)(((int16_t)buf[4]) | (((int16_t)buf[5]) << 8))) / 16.0;
}
void GetmRPY(double &x, double &y, double &z)
{
  uint8_t buf[6];
  i2c_com::readbuf(0x28, 0x0E, buf, 6);

  x = ((double)(((int16_t)buf[0]) | (((int16_t)buf[1]) << 8))) / 16.0;
  y = ((double)(((int16_t)buf[2]) | (((int16_t)buf[3]) << 8))) / 16.0;
  z = ((double)(((int16_t)buf[4]) | (((int16_t)buf[5]) << 8))) / 16.0;
}
void GetaRPY(double &x, double &y, double &z)
{
  uint8_t buf[6];
  i2c_com::readbuf(0x28, 0x08, buf, 6);

  x = ((double)(((int16_t)buf[0]) | (((int16_t)buf[1]) << 8))) / 100.0;
  y = ((double)(((int16_t)buf[2]) | (((int16_t)buf[3]) << 8))) / 100.0;
  z = ((double)(((int16_t)buf[4]) | (((int16_t)buf[5]) << 8))) / 100.0;
}
}

