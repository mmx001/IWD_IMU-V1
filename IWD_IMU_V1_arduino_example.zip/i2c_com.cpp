#include"i2c_com.h"


void i2c_com::initialize()
{
  Wire.begin();
}

uint8_t i2c_com::read8(uint8_t add, uint8_t reg)
{
  uint8_t value = 0;

  Wire.beginTransmission(add);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(add, 1);
  value = Wire.read();

  return value;

}

bool i2c_com::write8(uint8_t add, uint8_t reg, uint8_t value)
{
  Wire.beginTransmission(add);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();

  return true;
}

bool i2c_com::write(uint8_t add, uint8_t reg)
{
  Wire.beginTransmission(add);
  Wire.write(reg);
  Wire.endTransmission();

  return true;
}

bool i2c_com::readbuf(uint8_t add, uint8_t reg, uint8_t * buffer, uint8_t len)
{
  memset (buffer, 0, len);
  Wire.beginTransmission(add);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(add , len);

  for (uint8_t i = 0; i < len; i++)
  {
    buffer[i] = Wire.read();
  }
  return true;
}


